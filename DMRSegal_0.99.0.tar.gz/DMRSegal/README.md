
<!-- README.md is generated from README.Rmd. Please edit that file -->

# DMRSegal <img src="man/figures/package-sticker.png" align="right" height="139"/>

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
[![R-CMD-check](https://github.com/CMG-UA/DMRSegal/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/CMG-UA/DMRSegal/actions/workflows/R-CMD-check.yaml)
[![Codecov test
coverage](https://codecov.io/gh/CMG-UA/DMRSegal/branch/master/graph/badge.svg)](https://app.codecov.io/gh/CMG-UA/DMRSegal?branch=master)
<!-- badges: end -->

## Overview

DMRSegal is an R package for identifying Differentially Methylated
Regions (DMRs) from pre-computed Differentially Methylated Positions
(DMPs). The package implements a correlation-based approach to expand
regions around significant DMPs, considering both statistical
significance and biological relevance of methylation changes.

## Features

- Correlation-based region expansion from significant DMPs
- Support for both 450K and EPIC array platforms
- Parallel processing for improved performance
- Tabix-indexed file support for large datasets
- Memory-efficient processing through streaming approach
- Comprehensive DMR quality metrics and statistics
- Enhanced visualization tools for DMR analysis
- Integration with common methylation analysis workflows
- Flexible parameter tuning for customized DMR identification

## Important Note on Data Filtering

**⚠️ IMPORTANT:** Do not apply heavy filtering to your DMPs prior to
using DMRSegal, particularly based on beta values or effect sizes.
DMRSegal works by expanding regions around significant DMPs and
connecting nearby CpGs into larger regions. If you filter out DMPs with
smaller effect sizes, you may remove important CpGs that could serve as
“bridges” to connect more significant DMPs into larger, biologically
meaningful DMRs.

For optimal results:

- Include all statistically significant DMPs (e.g., adjusted p-value \<
  0.05)
- Let DMRSegal handle the region expansion and filtering internally
- Use the `min.cpg.delta_beta` parameter to filter based on effect size
  during the analysis if needed

## Installation

You can install the development version of DMRSegal from GitHub:

``` r
# install.packages("devtools")
devtools::install_github("CMG-UA/DMRSegal")
```

## Usage

Here’s a basic example of how to use DMRSegal:

``` r
library(DMRSegal)

# Load example data included with the package
data(example_beta)
data(example_dmps)
data(example_pheno)

# Create temporary files for the example
beta_file <- tempfile(fileext = ".txt")
write.table(
    cbind(ID = rownames(example_beta), example_beta),
    file = beta_file,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE
)

dmps_file <- tempfile(fileext = ".txt")
write.table(
    example_dmps,
    file = dmps_file,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE
)

# Find DMRs using parallel processing
dmrs <- findDMRsFromDMPs(
    beta.file = beta_file,
    dmps.tsv.file = dmps_file,
    pheno = example_pheno,
    sample_group.col = "group",
    array = "450K",  # Specify array platform
    min_cpgs = 3,
    min_dmps = 2,
    njobs = 2  # Use parallel processing
)

# Example of DMR statistics available
dmr_stats <- data.frame(
    width = width(dmrs),
    n_cpgs = mcols(dmrs)$n_cpgs,
    mean_delta_beta = mcols(dmrs)$mean_delta_beta,
    cases_beta = mcols(dmrs)$cases_beta,
    controls_beta = mcols(dmrs)$controls_beta,
    corr_pval = mcols(dmrs)$corr_pval
)

# View summary of DMR statistics
summary(dmr_stats)
```

## Workflow

1.  Start with pre-computed DMPs from any differential methylation
    analysis
2.  Provide methylation data:
    - Regular beta value files
    - Tabix-indexed files for large datasets
    - Support for both 450K and EPIC platforms
3.  Configure processing options:
    - Enable parallel processing for better performance
    - Adjust memory usage through streaming parameters
    - Set array platform-specific parameters
4.  Define DMR parameters:
    - Correlation and statistical thresholds
    - Region expansion criteria
    - Minimum CpG and DMP requirements
5.  Get comprehensive DMR results:
    - GRanges object with genomic locations
    - Detailed methylation statistics
    - Quality metrics for filtering
    - Platform-specific annotations

## Contributing

Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on our code
of conduct and the process for submitting pull requests.

## Citation

If you use DMRSegal in your research, please cite:

    To cite package 'DMRSegal' in publications use:

      Lemonidis V (2024). DMRSegal: Identify Differentially Methylated Regions from DMPs. R package version 0.99.0.
      University of Antwerp, Antwerp, Belgium.

    A BibTeX entry for LaTeX users is:

      @Manual{,
        title = {DMRSegal: Identify Differentially Methylated Regions from DMPs},
        author = {Vasileios Lemonidis},
        year = {2024},
        note = {R package version 0.99.0},
        url = {https://github.com/CMG-UA/DMRSegal},
      }

## License

This project is licensed under the GPL-2 License - see the
[LICENSE.md](LICENSE.md) file for details.

## Authors

- **Vasileios Lemonidis** - *Initial work* - \[University of Antwerp\]

## Acknowledgments

- Department of Medical Genetics, University of Antwerp
- Complex Medical Genetics Group
